import PySimpleGUI as sg

sg.Window(title="Hello World", layout=[ [] ], margins=(100, 50)).read()
